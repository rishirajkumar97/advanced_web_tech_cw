curl -X POST -H "Accept: application/vnd.github.v3+json" \
   -H "Authorization: token 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" \
  https://api.github.com/repos/rishirajkumar97/advanced_web_tech_cw/actions/workflows/spin-instances-down.yaml/dispatches \
  -d '{"ref":"main"}'
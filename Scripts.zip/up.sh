curl -X POST -H "Accept: application/vnd.github.v3+json" \
   -H "Authorization: token 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" \
  https://api.github.com/repos/rishirajkumar97/advanced_web_tech_cw/actions/workflows/spin-instances-up.yaml/dispatches \
  -d '{"ref":"main"}'